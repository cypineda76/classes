public class Principal{
	
	public Principal(){
		
	}
	
	public static void main(String args[]){
		System.out.println(".............:::::: Universidad Catolica de Colombia ::::::.............");
		System.out.println(".............:::::: Programacion Orientada a Objetos ::::::.............");
		System.out.println(".............:::::: <Cambiar por titulo de proyecto> ::::::.............");
		
		Principal principal = new Principal();
		
		
	}
}